#include<iostream>

using namespace std;


int main(){
    printf("hello world\n");
}
